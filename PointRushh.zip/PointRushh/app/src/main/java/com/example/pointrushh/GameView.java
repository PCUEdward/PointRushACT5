package com.example.pointrushh;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.Handler;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Random;

public class GameView extends SurfaceView implements SurfaceHolder.Callback {

    private final int boardWidth = 1080;
    private final int boardHeight = 2400;

    private final int birdWidth = 102; // Scaling bird width for higher resolution
    private final int birdHeight = 72; // Scaling bird height for higher resolution

    private final int pipeWidth = 192; // Scaling pipe width for higher resolution
    private final int pipeHeight = 1536; // Scaling pipe height for higher resolution

    private Bitmap backgroundImg;
    private Bitmap birdImg;
    private Bitmap topPipeImg;
    private Bitmap bottomPipeImg;

    private Paint paint;
    private Bird bird;
    private ArrayList<Pipe> pipes;
    private Random random = new Random();

    private Handler handler;
    private Runnable runnable;
    private int velocityX = -12; // Adjusted for higher resolution
    private int velocityY = 0;
    private int gravity = 3; // Adjusted for higher resolution

    private boolean gameOver = false;
    private double score = 0;
    private double highScore = 0;

    private RequestQueue requestQueue;
    private String serverUrl = "http://192.168.1.6:3000/";
    private String username;

    class Bird {
        int x, y, width, height;

        Bird(int x, int y, int width, int height) {
            this.x = x;
            this.y = y;
            this.width = width;
            this.height = height;
        }
    }

    class Pipe {
        int x, y, width, height;
        boolean passed;

        Pipe(int x, int y, int width, int height) {
            this.x = x;
            this.y = y;
            this.width = width;
            this.height = height;
            this.passed = false;
        }
    }

    public GameView(Context context, String username) {
        super(context);
        this.username = username;
        getHolder().addCallback(this);

        requestQueue = Volley.newRequestQueue(context);
        handler = new Handler();
        runnable = new Runnable() {
            @Override
            public void run() {
                if (!gameOver) {
                    update();
                    draw();
                }
                handler.postDelayed(this, 1000 / 60);
            }
        };

        paint = new Paint();
        backgroundImg = BitmapFactory.decodeResource(getResources(), R.drawable.flappybirdbg);
        birdImg = BitmapFactory.decodeResource(getResources(), R.drawable.flappybird);
        topPipeImg = BitmapFactory.decodeResource(getResources(), R.drawable.toppipe);
        bottomPipeImg = BitmapFactory.decodeResource(getResources(), R.drawable.bottompipe);

        bird = new Bird(boardWidth / 8, boardHeight / 2, birdWidth, birdHeight);
        pipes = new ArrayList<>();

        fetchHighScore();
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        handler.post(runnable);
        placePipes(); // Place initial pipes
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        handler.removeCallbacks(runnable);
    }

    private void update() {
        velocityY += gravity;
        bird.y += velocityY;
        bird.y = Math.max(bird.y, 0);

        for (Pipe pipe : pipes) {
            pipe.x += velocityX;

            if (!pipe.passed && bird.x > pipe.x + pipe.width) {
                score += 0.5;
                pipe.passed = true;
            }

            if (collision(bird, pipe)) {
                gameOver = true;
                handler.removeCallbacks(runnable);
                sendScoreToServer((int) score);
                updateHighScore(score);
            }
        }

        if (bird.y > boardHeight) {
            gameOver = true;
            handler.removeCallbacks(runnable);
            sendScoreToServer((int) score);
            updateHighScore(score);
        }

        // Remove off-screen pipes and add new ones
        if (pipes.size() > 0 && pipes.get(0).x < -pipeWidth) {
            pipes.remove(0);
            pipes.remove(0);
            placePipes();
        }
    }

    private void draw() {
        Canvas canvas = getHolder().lockCanvas();
        if (canvas != null) {
            // Draw background
            canvas.drawBitmap(backgroundImg, null, new Rect(0, 0, boardWidth, boardHeight), paint);

            // Draw bird
            Rect birdRect = new Rect(bird.x, bird.y, bird.x + bird.width, bird.y + bird.height);
            canvas.drawBitmap(birdImg, null, birdRect, paint);

            // Draw pipes
            for (Pipe pipe : pipes) {
                Rect pipeRect = new Rect(pipe.x, pipe.y, pipe.x + pipe.width, pipe.y + pipe.height);
                canvas.drawBitmap(pipe.y < 0 ? topPipeImg : bottomPipeImg, null, pipeRect, paint);
            }

            // Draw score
            paint.setColor(0xFFFFFFFF);
            paint.setTextSize(64); // Adjusted for higher resolution

            if (gameOver) {
                canvas.drawText("Game Over: " + (int) score, 10, 100, paint); // Adjusted for higher resolution
                canvas.drawText("High Score: " + (int) highScore, 10, 200, paint); // Adjusted for higher resolution
                if (score > highScore) {
                    highScore = score;
                    updateHighScore(score); // Update the high score on the server if the current score is higher
                }
            } else {
                canvas.drawText(String.valueOf((int) score), 10, 100, paint); // Adjusted for higher resolution
            }

            getHolder().unlockCanvasAndPost(canvas);
        }
    }

    private boolean collision(Bird bird, Pipe pipe) {
        return bird.x < pipe.x + pipe.width &&
                bird.x + bird.width > pipe.x &&
                bird.y < pipe.y + pipe.height &&
                bird.y + bird.height > pipe.y;
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            velocityY = -27; // Adjusted for higher resolution

            if (gameOver) {
                resetGame();
            }
        }
        return true;
    }

    private void resetGame() {
        bird.y = boardHeight / 2;
        velocityY = 0;
        pipes.clear();
        gameOver = false;
        score = 0;
        placePipes();
        handler.post(runnable);
    }

    private void placePipes() {
        int randomPipeY = (int) (pipeHeight / 4 + Math.random() * (pipeHeight / 2));
        int openingSpace = boardHeight / 4;

        Pipe topPipe = new Pipe(boardWidth, randomPipeY - pipeHeight, pipeWidth, pipeHeight);
        pipes.add(topPipe);

        Pipe bottomPipe = new Pipe(boardWidth, randomPipeY + openingSpace, pipeWidth, pipeHeight);
        pipes.add(bottomPipe);
    }

    private void sendScoreToServer(int score) {
        try {
            JSONObject jsonInput = new JSONObject();
            jsonInput.put("username", username);
            jsonInput.put("score", score);

            JsonObjectRequest jsonObjectRequest = new JsonObjectRequest
                    (Request.Method.POST, serverUrl + "score", jsonInput, new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            try {
                                if (response.getBoolean("success")) {
                                    updateHighScore(score); // Update high score after successfully submitting score
                                    fetchHighScore(); // Fetch updated high score
                                } else {
                                    Toast.makeText(getContext(), "Failed to update score on server", Toast.LENGTH_SHORT).show();
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Toast.makeText(getContext(), "Failed to send score to server", Toast.LENGTH_SHORT).show();
                        }
                    });

            requestQueue.add(jsonObjectRequest);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void fetchHighScore() {
        StringRequest stringRequest = new StringRequest(Request.Method.GET, serverUrl + "highscore?username=" + username,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonResponse = new JSONObject(response);
                            if (jsonResponse.getBoolean("success")) {
                                highScore = jsonResponse.getDouble("highScore");
                            } else {
                                Toast.makeText(getContext(), "Failed to fetch high score", Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getContext(), "Failed to fetch high score", Toast.LENGTH_SHORT).show();
            }
        });

        requestQueue.add(stringRequest);
    }

    private void updateHighScore(double score) {
        try {
            JSONObject jsonInput = new JSONObject();
            jsonInput.put("username", username);
            jsonInput.put("score", score);

            JsonObjectRequest jsonObjectRequest = new JsonObjectRequest
                    (Request.Method.POST, serverUrl + "update_highscore", jsonInput, new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            try {
                                if (response.getBoolean("success")) {
                                    System.out.println("High score updated successfully.");
                                } else {
                                    System.out.println("Failed to update high score.");
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Toast.makeText(getContext(), "Failed to update high score", Toast.LENGTH_SHORT).show();
                        }
                    });

            requestQueue.add(jsonObjectRequest);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}