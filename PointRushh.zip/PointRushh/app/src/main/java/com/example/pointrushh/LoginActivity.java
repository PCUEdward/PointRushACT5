package com.example.pointrushh;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

public class LoginActivity extends AppCompatActivity {

    private EditText usernameField, passwordField;
    private Button loginButton, signupButton, deleteAccountButton;
    private TextView messageLabel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        usernameField = findViewById(R.id.usernameField);
        passwordField = findViewById(R.id.passwordField);
        loginButton = findViewById(R.id.loginButton);
        signupButton = findViewById(R.id.signupButton);
        deleteAccountButton = findViewById(R.id.deleteAccountButton);
        messageLabel = findViewById(R.id.messageLabel);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loginUser();
            }
        });

        signupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                signupUser();
            }
        });

        deleteAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteAccount();
            }
        });
    }

    private void loginUser() {
        String username = usernameField.getText().toString();
        String password = passwordField.getText().toString();

        new UserAuthTask("login", username, password).execute();
    }

    private void signupUser() {
        String username = usernameField.getText().toString();
        String password = passwordField.getText().toString();

        new UserAuthTask("signup", username, password).execute();
    }

    private void deleteAccount() {
        String username = usernameField.getText().toString();
        String password = passwordField.getText().toString();

        new UserAuthTask("delete_account", username, password).execute();
    }

    private class UserAuthTask extends AsyncTask<Void, Void, String> {
        private String task;
        private String username;
        private String password;

        UserAuthTask(String task, String username, String password) {
            this.task = task;
            this.username = username;
            this.password = password;
        }

        @Override
        protected String doInBackground(Void... params) {
            try {
                URL url = new URL("http://192.168.1.6:3000/" + task);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json; utf-8");
                conn.setRequestProperty("Accept", "application/json");
                conn.setDoOutput(true);

                JSONObject jsonInput = new JSONObject();
                jsonInput.put("username", username);
                jsonInput.put("password", password);

                try (OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream())) {
                    writer.write(jsonInput.toString());
                    writer.flush();
                }

                int responseCode = conn.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "utf-8"));
                    StringBuilder response = new StringBuilder();
                    String responseLine;
                    while ((responseLine = br.readLine()) != null) {
                        response.append(responseLine.trim());
                    }
                    return response.toString();
                } else {
                    return "Error: " + responseCode;
                }
            } catch (Exception e) {
                e.printStackTrace();
                return "Exception: " + e.getMessage();
            }
        }

        @Override
        protected void onPostExecute(String result) {
            Log.d("UserAuthTask", "Result: " + result);
            if (result.contains("\"success\":true")) {
                if (task.equals("login")) {
                    Intent intent = new Intent(LoginActivity.this, GameActivity.class);
                    intent.putExtra("username", username);
                    startActivity(intent);
                } else {
                    messageLabel.setText(task + " successful. Please log in.");
                }
            } else {
                messageLabel.setText(task + " failed. " + result);
            }
        }
    }
}
